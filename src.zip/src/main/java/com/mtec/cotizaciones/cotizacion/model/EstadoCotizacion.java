package com.mtec.cotizaciones.cotizacion.model;

public enum EstadoCotizacion {
    BORRADOR,
    ENVIADA,
    APROBADA,
    RECHAZADA,
    COMPLETADA
}
