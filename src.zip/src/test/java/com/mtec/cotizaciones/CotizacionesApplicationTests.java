package com.mtec.cotizaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CotizacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
